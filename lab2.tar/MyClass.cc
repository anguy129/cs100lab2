//Allison Nguyen
//SID: 861204602
//Email: anguy129@ucr.edu
#include "./MyClass.h" 

MyClass::MyClass(); 
{} 

MyClass::~MyClass() 
{}
