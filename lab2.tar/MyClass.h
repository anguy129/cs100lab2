//Allison Nguyen
//SID: 861204602
//Email: anguy129@ucr.edu
#ifndef MyClass_h
#define MyClass_h

class MyClass
{
 public:
  MyClass();
  ~MyClass();

 private:
};
#endif
