#!/bin/sh




echo "First parameter: $1"

#echo "$@"
