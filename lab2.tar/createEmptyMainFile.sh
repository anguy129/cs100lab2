#!/bin/sh

cat _.txt > main.cpp

echo "" >> main.cpp
echo "int main(int argc, const char** argv)" >> main.cpp
echo "{ }" >> main.cpp

